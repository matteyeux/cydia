#ifndef JITSUPPORT_HEADER
#define JITSUPPORT_HEADER
#import <mach/mach.h>
#import <dlfcn.h>

__attribute__((unused))
static kern_return_t jit_mach_vm_allocate(mach_port_t task, mach_vm_offset_t* address, mach_vm_size_t size, int flags) {
    static kern_return_t (*impl)(mach_port_t task, mach_vm_offset_t* address, mach_vm_size_t size, int flags) = 0;
    if (!impl) {
        void *handle = dlopen("/usr/lib/jitsupport.dylib", RTLD_LAZY);
        if (handle)
            impl = (kern_return_t (*)(mach_port_t, const char*, mach_port_t *))dlsym(handle, "_impl_jit_mach_vm_allocate");
        if (!impl)
	    abort();
    }
    return impl(task,address,size,flags);
}
#endif
